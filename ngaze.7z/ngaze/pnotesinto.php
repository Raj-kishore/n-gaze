<?php
require"./connect.php";
error_reporting(E_ALL^E_NOTICE);
session_start();
$userid = $_SESSION['userid'];


$ndata=$_POST['ndata'];
$uid=$_POST['uid'];
$ndate= date("F d, Y");
date_default_timezone_set("Asia/Calcutta");
$ntime= date("h:i:sa");

mysql_query("INSERT INTO pnotes VALUES('','$ndata','$ndate','$ntime','$uid')");



$thisx=mysql_query("SELECT * FROM pnotes WHERE userid='$uid' ORDER BY id DESC");
while($fex=mysql_fetch_assoc($thisx)){
$nd=$fex['tr'];
$dat=$fex['ndat'];
$tim=$fex['ntym'];
$iid=$fex['id'];



$se=mysql_query("SELECT * FROM gazes WHERE tno='$iid'");
$nse=mysql_num_rows($se);

echo"
<div style='width:92%; background:rgba(108,108,108,0.1); margin:2%; padding:2%;'>
<div style='width:100%; text-align:left;'>
$nd
<div style=' font-size:17px; color:#4099FF;'>  
<span style='cursor:pointer;' id='d$iid'>Delete</span>

</div>
</div>
<div style='width:100%; height:20%; font-size:16px; text-align:right;'>
$tim | $dat
</div>
</div>
<div id='f1' style='position:fixed; display:none; top:0; left:0; width:100%;  height:100%; background:rgba(0,0,0,0.7);'></div>
<div id='f2$iid' style='position:fixed; display:none; top:0; left:0; padding:10px; right:0; margin-right:auto; margin-left:auto; width:30%; background:#fff;'>Are You Sure ?
<br/>
<a id='yesyes$iid' href='#!'>Yes</a>  |  <a id='nono' href='#!'>No</a>
</div>
<script>
$(document).ready(function(){
	$('#d$iid').click(function(){
		$('#f1').fadeIn(200);
		$('#f2$iid').fadeIn(200);
});
$('#nono').click(function(){
		$('#f1').fadeOut(200);
		$('#f2$iid').fadeOut(200);
});

$('#yesyes$iid').click(function(){
	var iffg=$iid;
	var dat=$userid
		
		$.ajax({
			url:'./deldel.php',
			type:'POST',
			data:{iffg:iffg},
			success:function(){
				
					window.location.href='./pnote.php';
				
				}
		
			
			});
});
	
	});
</script>
";


}

?>