<?php


require"./connect.php";

$emai=$_POST['emailx'];


$qu=mysql_query("SELECT * FROM newusers WHERE email='$emai'");
$fqu=mysql_fetch_assoc($qu);
$num=mysql_num_rows($qu);
	$ffqu=$fqu['id'];

if($num==0){

echo"

Oops the email you entered doesn't exists. <a href='./index.php'>Go back to the previous page.</a> 

";
	
	}else{
		
		$newpass=$ffqu.'gry';
		
		mysql_query("UPDATE newusers SET pass='$newpass' WHERE email='$emai'");
		
		
		mail("$emai","Keengaze
: Password changed.","Your new password is :".$newpass."<br/>www.ngaze.com");
		
		
		
	echo"
A new password has been sent to your email.Please check your email.<a href='./index.php'>Go back to the previous page.</a> 
";

		}
	
	


?>