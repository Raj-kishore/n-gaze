<?php
error_reporting(E_ALL^E_NOTICE);
session_start();
$userid = $_SESSION['userid'];
$username = $_SESSION['username'];	
?>
<?php
require "./connect.php";

$user=$_GET['uid'];

$currentp=mysql_real_escape_string($_POST['curp']);
$newp=mysql_real_escape_string($_POST['np']);
$nameh=$_POST['nameh'];

$valid_formats = array("jpg", "png", "gif", "bmp");
$name = $_FILES['photoimg']['name'];
$size = $_FILES['photoimg']['size'];
$tmp = $_FILES['photoimg']['tmp_name'];
$path = "img/";


$thij=mysql_query("SELECT * FROM newusers WHERE id='$user'");
$thfet=mysql_fetch_assoc($thij);
$passd=$thfet['pass'];

if($passd==$currentp){
	mysql_query("UPDATE newusers SET pass='$newp' WHERE id='$userid'");
	 header("location: http://localhost/setme.php?op=k");
	}else{
		if($currentp!=""){
		
			 header("location: http://localhost/setme.php?op=m");
		}else{
			
			 header("location: http://localhost/setme.php");
			}
		
		}



if(move_uploaded_file($tmp, $path.$name))

								{
									
									
                    mysql_query("INSERT INTO nfiles VALUES('','$user','$name')");


								}
								
					mysql_query("UPDATE newusers SET uname='$nameh' WHERE id='$userid'");
								

 //$last= mysql_insert_id();

					
 
?>