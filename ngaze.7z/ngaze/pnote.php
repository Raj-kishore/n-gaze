<?php
error_reporting(E_ALL^E_NOTICE);
session_start();
$userid = $_SESSION['userid'];
$uu=$_GET['id'];
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Tash here!</title>

<script src="jquery.min.js"></script>


<style>
.notes{
	font-family:"Gill Sans", "Gill Sans MT", "Myriad Pro", "DejaVu Sans Condensed", Helvetica, Arial, sans-serif;
	color:#333;	
}
body{
	background:url(all/explore-clouds-powerpoint-backgrounds.jpg);
	background-size:cover;
	background-attachment:fixed;
		-webkit-transition: all 0.2s ease;
	-moz-transition: all 0.2s ease;
	-ms-transition: all 0.2s ease;
	-o-transition: all 0.2s ease;
	transition: all 0.2s ease;
	
}
#feedy{
	display:inline-block; width:25%; color:#ccc; vertical-align:top; background:#fff;}
	#dfdfdf{
		display:inline-block; width:65%; vertical-align:top; color:#575757;  background:#fff;}
	#td{
		width:100%; height:20%; font-size:16px; text-align:right;
	}
	#l1{display:inline-block; width:20%; height:100%; color:#424242; position:relative;}
	#l2{display:inline-block; width:55%; height:100%; background:#4099FF; text-align:left; color:#999; position:relative;}
	#l3{display:inline-block; width:20%; height:100%; background:#4099FF; position:relative;}
@media screen and (max-width: 730px) {
	#l1{ width:100%;}
	#l2{ display:none;}
	#l3{ width:100%;}

#feedy{
	display:inline-block; width:100%; color:#ccc; vertical-align:top; background:#fff;
	}
#dfdfdf{
	display:inline-block; width:100%; vertical-align:top; color:#575757;  background:#fff;}
	#td{
		margin-top:10px;
	font-size:12px;
		}
}

</style>
</head>

<body>
<div style="position:fixed; width:100%; background:rgb(64, 153, 255); top:0; left:0; font-family:'Gill Sans', 'Gill Sans MT', 'Myriad Pro', 'DejaVu Sans Condensed', Helvetica, Arial, sans-serif; font-size:30px; height:50px; color:white; ">
<div style="text-align:center; width:100%; height:100%;">

<div id='l1'>
<div style=" position:absolute; margin-top:7px;  color:#fff; left:0; right:0; margin-left:auto; margin-right:auto;"><a style=" color:#fff; text-decoration:none; cursor:pointer;" href='./trash.php'>
Keengaze

</a></div>
</div>

<div id='l2'>



</div>
<div id='l3'>

<div style=" position:absolute; margin-top:2px;  color:#999; padding-left:10px; left:0; right:0; margin-left:auto; margin-right:auto;">

<?php
if(!isset($userid)){
echo "

<a style='color:#fff; text-decoration:none; font-size:16px;' href='./index.php'>
Log In
</a>
";
}else{
	echo"
	
<a style='color:#fff; text-decoration:none; margin-right:30px; font-size:16px;' href='./setme.php'>Setting</a>
	<a style='color:#fff; text-decoration:none; font-size:16px;' href='./index.php'>
Log out
</a>
	";

	}
?>
</div>
</div>
</div>
</div>


<div style="width:1000px; margin:10px auto; position:relative; margin-bottom:10px; background:rgba(255,255,255,0.7); color:#fff; font-family:'Gill Sans', 'Gill Sans MT', 'Myriad Pro', 'DejaVu Sans Condensed', Helvetica, Arial, sans-serif; font-size:24px; border-radius:10px; ">



</div>

<div style="width:90%; margin:10px auto; margin-top:150px; margin-bottom:100px; font-family:'Gill Sans', 'Gill Sans MT', 'Myriad Pro', 'DejaVu Sans Condensed', Helvetica, Arial, sans-serif; background:rgba(255,255,255,0.8); border-radius:10px;">

<div style=" color:#4099FF; float:left; margin:10px; font-size:20px; cursor:pointer;"><a style="text-decoration:none; color:#4099FF; " href="./trash.php">Feeds</a></div>

<div style=' color:#4099FF; float:left; margin:10px; font-size:20px;  cursor:pointer;'><a style="text-decoration:none; color:#4099FF; " href="./trash.php">Profile</a></div>




<?php
if(isset($userid)){

echo"

<div style=' color:#4099FF; float:left; margin:10px; font-size:20px; cursor:pointer;'><a style='text-decoration:none; color:#4099FF; ' href='./gaze.php'>Gazes</a></div>
<div style='color:#4099FF; float:left; margin:10px; font-size:20px; text-decoration:underline; '>
Private notes
</div>
";
}
?>
<div style="clear:both;"></div>


<?php
if(isset($userid)){

echo"
<div id='poster'>
<textarea id='ndata' name='textarea' style=\"background:#fff; width:98%; border:0; outline:0; height:100px; font-family:'Gill Sans', 'Gill Sans MT', 'Myriad Pro', 'DejaVu Sans Condensed', Helvetica, Arial, sans-serif; font-size:18px; padding:1%;\" placeholder='What you think...'>
</textarea>
<input type='text' id='uid' style='display:none;' value='$userid'/>
<div id='into' style='background:#fff; width:98%; cursor:pointer; padding:1%; background:#4099FF; color:#fff; font-size:20px; text-align:center;'>Post</div>
</div>
";



}

?>


<script>
$(document).ready(function(e) {
	
	
	
	
	

	var uid = $('#uid').val();

    $("#into").click(function(e){
		var ndata = $('#ndata').val();	
		
		if(ndata==""){
	
		}else{
					
		$.ajax({
			url:"./pnotesinto.php",
			type:"POST",
			data:{ndata:ndata,uid:uid},
			beforeSend: function(){
				$('#dfdfdf').html("<div style='margin-top:30px; margin-bottom:30px;'>Loading...<div>");
				},
			success: function(data){
				$('#dfdfdf').html(data);
				$('#ndata').val("");
				
				}
		  
			});
			
			
			};
		});
});
</script>
<div style=" width:100%; color:#fff; font-size:20px; text-align:center;">



<div id='dfdfdf'>
<?php
require"./connect.php";
$thisx=mysql_query("SELECT * FROM pnotes WHERE userid='$userid' ORDER BY id DESC");
while($fex=mysql_fetch_assoc($thisx)){
$nd=$fex['tr'];
$dat=$fex['ndat'];
$tim=$fex['ntym'];
$iid=$fex['id'];



	echo"
<div style='width:92%;  background:rgba(108,108,108,0.1); margin:2%; padding:2%;'>
<div style='width:100%; text-align:left;'>
<div id='ju$iid' style='cursor:pointer;'>
$nd
</div>
<div style=' font-size:17px; color:#4099FF;'>  

";


echo"
<span style='cursor:pointer;' id='d$iid'>Delete</span>
</div>


</div>
<div style='width:100%; height:20%; font-size:16px; text-align:right;'>
<div id='td'>
$tim | $dat
</div>
</div>
</div>
<div id='f1' style='position:fixed; display:none; top:0; left:0; width:100%;  height:100%; background:rgba(0,0,0,0.7);'></div>
<div id='f2$iid' style='position:fixed; display:none; top:0; left:0; padding:10px; right:0; margin-right:auto; margin-left:auto; width:30%; background:#fff;'>Are You Sure ?
<br/>
<a id='yesyes$iid' href='#!'>Yes</a>  |  <a id='nono' href='#!'>No</a>
</div>
<script>
$(document).ready(function(){
	
	
		
	$('#ju$iid').hover(function(){
		$(this).css({'color':'#000'});
	},function(){
			$(this).css({'color':'#696969'});
		
		});
	
		$('#ju$iid').click(function(){
			
			var hii=$iid;
	
		window.location.href='./wherep.php?tid='+hii;
	
	});
	
	
	
	
	$('#d$iid').click(function(){
		$('#f1').fadeIn(200);
		$('#f2$iid').fadeIn(200);
});
$('#nono').click(function(){
		$('#f1').fadeOut(200);
		$('#f2$iid').fadeOut(200);
});

$('#yesyes$iid').click(function(){
	var iffg=$iid;
	var dat=$userid;
		
		$.ajax({
			url:'./deldel.php',
			type:'POST',
			data:{iffg:iffg},
			success:function(){
				
					window.location.href='./pnote.php';
				
				}
		
			
			});
});
	
	});
</script>
";
	
	

}
?>




</div>


</div>

</div>

</div>

<div id='text2' style=" color:#fff; font-family:'Gill Sans', 'Gill Sans MT', 'Myriad Pro', 'DejaVu Sans Condensed', Helvetica, Arial, sans-serif; font-size:16px; width:50%; margin:auto; text-align:center; height:100px;">Copyright 2015 | All Rights Reserved | <a style="color:#fff; text-decoration:none;" href="./aboutn.php">About</a></div>

<div id='text3' style="color:#fff; font-family:'Gill Sans', 'Gill Sans MT', 'Myriad Pro', 'DejaVu Sans Condensed', Helvetica, Arial, sans-serif; font-size:16px;  width:50%; margin:auto; text-align:center; height:100px;">Powered by RAJ KM</div>

</body>
</html>