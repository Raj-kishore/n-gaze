<?php
require"./connect.php";


$tid=$_POST['thrc'];
$uid=$_POST['uidc'];

$io=mysql_query("DELETE FROM gazes WHERE tno='$tid' AND uid='$uid'");
	


$se=mysql_query("SELECT * FROM gazes WHERE tno='$tid'");
$nse=mysql_num_rows($se);

echo "$nse gazes ";



?>