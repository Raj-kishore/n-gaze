
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<style>
body{
	background:url(all/explore-clouds-powerpoint-backgrounds.jpg);
	background-size:cover;
	background-attachment:fixed;
		-webkit-transition: all 0.2s ease;
	-moz-transition: all 0.2s ease;
	-ms-transition: all 0.2s ease;
	-o-transition: all 0.2s ease;
	transition: all 0.2s ease;
	
}
#container{
	position:absolute; 
	top:80px; 
	left:0;
	 right:0;
	   margin-top:auto; margin-left:auto; margin-right:auto; width:80%;  background:rgba(255,255,255,1);}

	#l1{display:inline-block; width:20%; height:100%; color:#424242; position:relative;}
	#l2{display:inline-block; width:55%; height:100%; background:#4099FF; text-align:left; color:#999; position:relative;}
	#l3{display:inline-block; width:20%; height:100%; background:#4099FF; position:relative;}
	
	@media screen and (max-width: 730px) {
	#l1{ width:100%;}
	#l2{ display:none;}
	#l3{ display:none;}

	
	}
</style>
</head>

<body>

<div style="position:fixed; z-index:1000; width:100%; background:rgb(64, 153, 255); top:0; left:0; font-family:'Gill Sans', 'Gill Sans MT', 'Myriad Pro', 'DejaVu Sans Condensed', Helvetica, Arial, sans-serif; font-size:30px; height:50px; color:white; ">
<div style="text-align:center; width:100%; height:100%;">

<div id='l1' >
<div style=" position:absolute; z-index:1000; margin-top:7px;  color:#fff; left:0; right:0; margin-left:auto; margin-right:auto;">
<a style=" color:#fff; text-decoration:none; cursor:pointer;" href='../../form/ngaze/notepad.php'>
Keengaze
</a>
</div>
</div>

<div id='l2' >



</div>
<div id='l3'>

<div style=" position:absolute; margin-top:2px;  color:#999; padding-left:10px; left:0; right:0; margin-left:auto; margin-right:auto;">


</div>

</div>
</div>
</div>

<div id='container' >
<div style="margin:30px; font-size:24px; font-family:'Gill Sans', 'Gill Sans MT', 'Myriad Pro', 'DejaVu Sans Condensed', Helvetica, Arial, sans-serif; color:#939393;">
About 
</div>
<br/>
<div style="margin:30px; font-size:18px; font-family:'Gill Sans', 'Gill Sans MT', 'Myriad Pro', 'DejaVu Sans Condensed', Helvetica, Arial, sans-serif; color:#939393;">
With Keengaze you can save notes in the web.
When your data is in the web, you can access it anywhere and anytime by signing in to the Keengaze.
Sign up, create a profile and publish brief written record of facts, topics, thoughts with the users or you can be personal with private notes. Gaze awesome notes and read it later from your 'Gazes' tab.<br/>
Listen - " Keengaze can be used as an 'Aid to memory' tool. "<br/>
This website is growing up. <br/>
</div>
<br/>
<div style="margin:30px; font-size:18px; font-family:'Gill Sans', 'Gill Sans MT', 'Myriad Pro', 'DejaVu Sans Condensed', Helvetica, Arial, sans-serif; color:#939393;">
This website will last forever for free. Trust us, keep posting. Thank you. 
<br/><br/>
Contact: 
<br/> quickroutes@gmail.com

<div id='text2' style=" color:#999; font-family:'Gill Sans', 'Gill Sans MT', 'Myriad Pro', 'DejaVu Sans Condensed', Helvetica, Arial, sans-serif; font-size:16px; width:50%; margin:auto; margin-bottom:50px; text-align:center; height:50px; margin-top:50px;">Copyright 2015 <br/> All Rights Reserved <br/><br/> Powered by RAJ KM </div>


</div>



</body>
</html>