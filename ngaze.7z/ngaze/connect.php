<?php
$mysql_error="Down time error";
mysql_connect('localhost','root','') or die ($mysql_error);
mysql_select_db('keengaze') or die ($mysql_error);
?>