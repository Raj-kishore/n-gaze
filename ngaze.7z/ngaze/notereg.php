<?php
require"./connect.php";
$emm=$_POST['emm'];
$pss=$_POST['pss'];
$unn=$_POST['unn'];
mysql_query("INSERT INTO newusers VALUES('','$emm','$pss','$unn')");



error_reporting(E_ALL^E_NOTICE);
session_start();

$last=mysql_insert_id();

$_SESSION['userid']=$last;	
echo $last ;




?>