<?php
error_reporting(E_ALL^E_NOTICE);
session_start();
$userid = $_SESSION['userid'];
$uu=$_GET['id'];
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Tash here!</title>

<script src="jquery.min.js"></script>


<style>
.notes{
	font-family:"Gill Sans", "Gill Sans MT", "Myriad Pro", "DejaVu Sans Condensed", Helvetica, Arial, sans-serif;
	color:#333;	
}
body{
	background:url(all/explore-clouds-powerpoint-backgrounds.jpg);
	background-size:cover;
	background-attachment:fixed;
	-webkit-transition: all 0.2s ease;
	-moz-transition: all 0.2s ease;
	-ms-transition: all 0.2s ease;
	-o-transition: all 0.2s ease;
	transition: all 0.2s ease;
}
	#l1{display:inline-block; width:20%; height:100%; color:#424242; position:relative;}
	#l2{display:inline-block; width:55%; height:100%; background:#4099FF; text-align:left; color:#999; position:relative;}
	#l3{display:inline-block; width:20%; height:100%; background:#4099FF; position:relative;}
	
	@media screen and (max-width: 730px) {
	#l1{ width:100%;}
	#l2{ display:none;}
	#l3{ width:100%;}

	
	}

</style>
</head>

<body>
<div style="position:absolute; width:100%; background:rgb(64, 153, 255); top:0; left:0; font-family:'Gill Sans', 'Gill Sans MT', 'Myriad Pro', 'DejaVu Sans Condensed', Helvetica, Arial, sans-serif; font-size:30px; height:50px; color:white; ">
<div style="text-align:center; width:100%; height:100%;">

<div id='l1' >
<div style=" position:absolute; margin-top:7px;  color:#fff; left:0; right:0; margin-left:auto; margin-right:auto;">
<a style=" color:#fff; text-decoration:none; cursor:pointer;" href='./trash.php'>
Keengaze

</a>
</div>
</div>

<div id='l2' >



</div>
<div id='l3'>

<div style=" position:absolute; margin-top:2px;  color:#999; padding-left:10px; left:0; right:0; margin-left:auto; margin-right:auto;">

<a style="color:#fff; text-decoration:none; font-size:16px;" href="./logmeout.php">Log out</a>

</div>

</div>
</div>
</div>


<div style="width:85%; margin:10px auto; position:relative; margin-bottom:10px; background:rgba(255,255,255,0.7); color:#fff; font-family:'Gill Sans', 'Gill Sans MT', 'Myriad Pro', 'DejaVu Sans Condensed', Helvetica, Arial, sans-serif; font-size:24px; border-radius:10px; ">



</div>

<div style="width:85%; margin:10px auto; margin-top:150px; margin-bottom:50px; font-family:'Gill Sans', 'Gill Sans MT', 'Myriad Pro', 'DejaVu Sans Condensed', Helvetica, Arial, sans-serif; background:rgba(255,255,255,0.8); border-radius:10px;">



<div style=" width:100%; color:#fff; font-size:20px; text-align:center; ">


<div style="width:100%; color:#999;">
<br/>
<br/>
Profile options<br/><br/>
<form method="post" enctype="multipart/form-data" action="./changeme.php?uid=<?php echo $userid ?>">
<?php
require"./connect.php";
$nnn=mysql_query("SELECT * FROM nfiles WHERE uid='$userid' ORDER BY id DESC");
$nnnn=mysql_fetch_assoc($nnn);
$immg=$nnnn['hspot'];


if($immg){
	echo"

<img style=' margin:10px; border-radius:35px; cursor:pointer;' width='70px' height='70px' src='img/$immg'><br/>
";
	
	}
else{
	echo"

<img style=' margin:10px; border-radius:35px; cursor:pointer;' width='70px' height='70px' src='all/ano.jpg'><br/>
";
	
	}

?>



<input id='photoimg' name="photoimg" type="file"/>
<div style=" margin:20px; color:#999; font-size:16px;">
<?php
$thisxy=mysql_query("SELECT * FROM newusers WHERE id='$userid'");
$fexy=mysql_fetch_assoc($thisxy);
$nameof=$fexy['uname'];
$pass=$fexy['pass'];
echo"
<input type='text' id='nameh' name='nameh' value='$nameof' placeholder='Username'/>
";
?>
</div> 
Change password <br/><br/>
<input type="text" id='curp' name='curp'  placeholder="Current password"/><br/>
<input type="text" id='np' name='np' placeholder="New password"/><br/><br/>
<input type="submit" style="background:#4099FF; cursor:pointer; float:right; margin-right:30px; color:#fff; border:0; outline:0; padding:6px; border-radius:3px;" value="Done"/>
</form>
<div style="clear:both;"></div>

<?php
$op=$_GET['op'];
if($op==k){
	echo "Password successfully changed.";
	}else if($op==m){
		echo "<span style='color:red;'>Incorrect current password !</span>";
		}

?>

</div>
<div id='dfdfdf' style="display:inline-block; width:65%; vertical-align:top; color:#575757;  background:#fff;">
</div>
</div>
</div>
</div>

<div id='text2' style=" color:#fff; font-family:'Gill Sans', 'Gill Sans MT', 'Myriad Pro', 'DejaVu Sans Condensed', Helvetica, Arial, sans-serif; font-size:16px; width:50%; margin:auto; text-align:center; height:100px;">Copyright 2015 | All Rights Reserved | <a style="color:#fff; text-decoration:none;" href="./aboutn.php">About</a></div>

<div id='text3' style="color:#fff; font-family:'Gill Sans', 'Gill Sans MT', 'Myriad Pro', 'DejaVu Sans Condensed', Helvetica, Arial, sans-serif; font-size:16px;  width:50%; margin:auto; text-align:center; height:100px;">Powered by RAJ KM</div>
</body>
</html>