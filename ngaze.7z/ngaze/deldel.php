<?php
require"./connect.php";
$getme=$_POST['iffg'];
if(mysql_query("DELETE FROM pnotes WHERE id='$getme'")){
	
	echo "1";
	}

?>