<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<script src="jquery-1.10.2.js"></script>
</head>

<body>
<script>
$(document).ready(function(e) {
    alert('ok');
});
</script>
</body>
</html>