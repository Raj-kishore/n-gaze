<?php
require"./connect.php";
error_reporting(E_ALL^E_NOTICE);
session_start();
$userid = $_SESSION['userid'];


$ndata=$_POST['ndata'];
$uid=$_POST['uid'];
$ndate= date("F d, Y");
date_default_timezone_set("Asia/Calcutta");
$ntime= date("h:i:sa");

mysql_query("INSERT INTO tyo VALUES('','$ndata','$ndate','$ntime','$uid')");


$find=mysql_query("SELECT * FROM tyo ORDER BY id DESC");
while($ffind=mysql_fetch_assoc($find)){
$txtid=$ffind['id'];
$txts=$ffind['ndata'];
$timex=$ffind['ntime'];
$datex=$ffind['ndate'];
$user=$ffind['uid'];

$uquery=mysql_query("SELECT * FROM newusers WHERE id='$user'");
$finder=mysql_fetch_assoc($uquery);
$nameget=$finder['uname'];
$idget=$finder['id'];



$se=mysql_query("SELECT * FROM gazes WHERE tno='$txtid'");
$nse=mysql_num_rows($se);



$co=mysql_query("SELECT * FROM gazes WHERE tno='$txtid' AND uid='$userid'");
$coo=mysql_num_rows($co);


if($coo=="0"){

echo"

<div style='width:92%;  background:rgba(108,108,108,0.1); margin:2%; padding:2%;'>
<div style='text-align:left; padding-bottom:10px; font-size:16px; '>
<a style='text-decoration:none; color:#4099FF; ' href='./npadpro.php?id=$user'>$nameget</a>
</div>
<div  style='width:100%; text-align:left;'>
<div id='ju$txtid'>
$txts
</div>
<div style='position:relative; width:100%;'>
<div id='b$txtid' style='width:100%; position:absolute; top:0; left:0; color:#4099FF;'> Gaze </div>
<div id='c$txtid' style='width:100%; position:absolute; top:0; left:0; display:none; color:#4099FF;'> Ungaze </div>
</div>
<div id='nhere$txtid' style='width:100%; margin-top:25px; font-size:16px; color:#999; '>$nse gaze</div>
<script>
$(document).ready(function(){
	
	$('#ju$txtid').hover(function(){
		$(this).css({'color':'#000'});
	},function(){
			$(this).css({'color':'#696969'});
		
		});
	
		$('#ju$txtid').click(function(){
			
			var hii=$txtid;
	
		window.location.href='./where.php?tid='+hii;
	
	});
	
	
	$('#b$txtid').click(function(){
		var uidc=$userid;
		var thrc=$txtid;
	
	$.ajax({
		url:'./gazeme.php',
		type:'POST',
		data:{uidc:uidc,thrc:thrc},
		success:function(data){
			
			$('#c$txtid').fadeIn(200);
			$('#b$txtid').fadeOut(200);
			$('#nhere$txtid').html(data);
		
			}
		});
		
		
			});
			
				
	$('#c$txtid').click(function(){
			var uidc=$userid;
		var thrc=$txtid;
	
	$.ajax({
		url:'./ungazeme.php',
		type:'POST',
		data:{uidc:uidc,thrc:thrc},
		success:function(data){
			$('#b$txtid').fadeIn(200);
			$('#c$txtid').fadeOut(200);
			$('#nhere$txtid').html(data);
			}
		});
		
		
			});
	
	});
</script>
</div>
<div style='width:100%; height:20%; font-size:16px; text-align:right;'>
$timex | $datex
</div>
</div>


";
}else{
	echo"

<div style='width:92%; background:rgba(108,108,108,0.1); margin:2%; padding:2%;'>
<div style='text-align:left; padding-bottom:10px; font-size:16px; '>
<a style='text-decoration:none; color:#4099FF; ' href='./npadpro.php?id=$user'>$nameget</a>
</div>
<div  style='width:100%; text-align:left;'>
<div id='ju$txtid'>
$txts
</div>
<div style='position:relative; width:100%;'>
<div id='b$txtid' style='width:100%; position:absolute; top:0; left:0; display:none; color:#4099FF;'> Gaze </div>
<div id='c$txtid' style='width:100%; position:absolute; top:0; left:0;  color:#4099FF;'> Ungaze </div>
</div>
<div id='nhere$txtid' style='width:100%; margin-top:25px; font-size:16px; color:#999; '>$nse gaze</div>
<script>
$(document).ready(function(){
	
	$('#ju$txtid').hover(function(){
		$(this).css({'color':'#000'});
	},function(){
			$(this).css({'color':'#696969'});
				
		});
	
		$('#ju$txtid').click(function(){
			
			var hii=$txtid;
	
		window.location.href='./where.php?tid='+hii;
	
	});
	
	
	$('#b$txtid').click(function(){
		var uidc=$userid;
		var thrc=$txtid;
	
	$.ajax({
		url:'./gazeme.php',
		type:'POST',
		data:{uidc:uidc,thrc:thrc},
		success:function(data){
			
			$('#c$txtid').fadeIn(200);
			$('#b$txtid').fadeOut(200);
			$('#nhere$txtid').html(data);
		
			}
		});
		
		
			});
			
				
	$('#c$txtid').click(function(){
			var uidc=$userid;
		var thrc=$txtid;
	
	$.ajax({
		url:'./ungazeme.php',
		type:'POST',
		data:{uidc:uidc,thrc:thrc},
		success:function(data){
			$('#b$txtid').fadeIn(200);
			$('#c$txtid').fadeOut(200);
			$('#nhere$txtid').html(data);
			}
		});
		
		
			});
	
	});
</script>
</div>
<div style='width:100%; height:20%; font-size:16px; text-align:right;'>
$timex | $datex
</div>
</div>


";
	
	}

}
?>
