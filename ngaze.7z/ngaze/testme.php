<?php
require"./connect.php";


error_reporting(E_ALL^E_NOTICE);
session_start();

$uname=$_POST['unameu'];
$pass=$_POST['passu'];





$result = mysql_query("SELECT * FROM newusers WHERE uname = '$uname' AND  pass ='$pass'");

if($row=mysql_fetch_array($result))
{
	
	$id=$row['id'];


$_SESSION['userid']=$id;	
	echo"1";
}
else
{
	echo "0";
	}



?>