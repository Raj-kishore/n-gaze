<?php
error_reporting(E_ALL^E_NOTICE);
session_start();
$userid = $_SESSION['userid'];
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Keengaze | Welcome page</title>
<style>
.notes{
	font-family:"Gill Sans", "Gill Sans MT", "Myriad Pro", "DejaVu Sans Condensed", Helvetica, Arial, sans-serif;
	color:#333;	
}
body{
	
	background-attachment:fixed;
	background:url(all/explore-clouds-powerpoint-backgrounds.jpg);
	background-size:cover;
    -webkit-transition: all 0.2s ease;
	-moz-transition: all 0.2s ease;
	-ms-transition: all 0.2s ease;
	-o-transition: all 0.2s ease;
	transition: all 0.2s ease;
}
</style>

<script src="jquery-1.10.2.js"></script>
<script src="jquery.nicescroll.min.js"></script>
<script>
$(document).ready(
  function() { 
    $("#secpagein").niceScroll({cursorcolor:"#4099FF",horizrailenabled:false});
 }
);
</script>
<script>
$(document).ready(
  function() { 
    $("#smec").niceScroll({cursorcolor:"#4099FF",horizrailenabled:false});
 }
);
</script>

<script>
$(document).ready(function(e) {
	

	
	$('#pen').click(function(){
	        $('#firstpage').fadeOut();
	    
			   $('#penthen').animate({"width":"10%"},300);
			$('#penthen').animate({"width":"7%"},300);
			
			//$('#penthen').animate({"transition":"rotate(180deg)"},200);
		});
		
    $('#penthen').click(function(){
	        $('#secpage').fadeOut();
			$('#tex').val("");
			
	    });
		
		   $('#okbut').click(function(){
	      alert('jbkh');
	    });
		
		
		 $('#gear').click(function(){
	       $('#firstpage').fadeOut();
		   $('#setpage').fadeIn();
	    });
		
    $('.notes').click(function(){
	        $('#fourthpage').fadeIn();
	    });

    $('#De').click(function(){
	        $('#dbut').fadeIn();
	    });
	
    $('#can').click(function(){
	        $('#dbut').fadeOut();
	    });
		
		
		
    $('#ba').click(function(){
	        $('#fourthpage').fadeOut();
        $('#back').click();
        });
		
		
		    $('#login').click(function(){
				
				$('#errory').fadeOut();
	        $('#sup').toggle(200);
			$('#loggg').toggle(200);
			$(this).toggle(200);
			$('#loginn').toggle(200);
			
        });
		 $('#loginn').click(function(){
	        $('#login').click();
			
        });
		

    $('#back').click(function(){
	    $('#secpage').fadeIn();
		$('#old').fadeOut();
	
	 $.ajax({
        url:"noteout.php",
        success: function (data) {
	      $('#container').fadeIn(200);
	      $('#container').html(data);
	
	
        },
    });
	
	
	
	
	
});










    $('#rthis').click(function(e){

    var unn=$('#uname').val();
	var emm=$('#email').val();
	var pss=$('#pass').val();
	
			 
	
	if(unn==''&&emm==''&&pss==''){
	$('#error123').fadeIn();

$('#error123').fadeOut();

};
	if(unn!=''&&emm==''&&pss==''){
	$('#error23').fadeIn();
	$('#error23').fadeOut();

			}
				if(unn==''&&emm!=''&&pss==''){
					
				
	$('#error13').fadeIn();
	$('#error13').fadeOut();
					
			}
				if(unn==''&&emm==''&&pss!=''){
				
	$('#error12').fadeIn();
		$('#error12').fadeOut();
	
			}
			
			
			
				if(unn!=''&&emm!=''&&pss==''){
				
	$('#error3').fadeIn();
	$('#error3').fadeOut();
			}
				if(unn==''&&emm!=''&&pss!=''){
				$('#error1').fadeIn();
					$('#error1').fadeOut();

			}
				if(unn!=''&&emm==''&&pss!=''){
	$('#error2').fadeIn();
		$('#error2').fadeOut();

			}
			
			
			

	
			
			if(unn!=''&&emm!=''&&pss!=''){
	
			
				 $.ajax({
        url:"notereg.php",
        type: 'POST',
        data: {unn:unn,emm:emm,pss:pss},
        success: function (data) {
		
			
					window.location.href='./npadpro.php?uid='+data;
			

        },
        cache: false,
      
 
		
		
		});
	
	
	
			}
		
		});



   $('#email').bind("keyup",function(e){
	   
	   
	   	var emmi=$('#email').val();

	if(validateEmail(emmi)==false){
			$('#errorx').fadeIn();
			
				$('#errory').fadeOut();
								}else{
						$('#errory').fadeIn();
						
							$('#errorx').fadeOut();
						}

   });



						function validateEmail(email) {
    var re = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
    return re.test(email);
                                                    }	





	


$('#cnew').click(function(){
	var text = $('#tex').val(); 
	var userid = $('#user').val(); 
	
		 $.ajax({
        url:"notein.php",
        type: 'POST',
        data: {text:text,userid:userid},
        success: function (data) {
				window.location.href = "http://localhost/npadpro.php";
        }
       
      
 
		
		
		});
	
	
});
});
</script>
<script src="jquery.nicescroll.min.js"></script>
<script>
$(document).ready(
  function() { 
    //$("html").niceScroll("#secpage",{cursorcolor:"#4099FF",horizrailenabled:false});
 }
);
</script>
</head>

<body>




<!--Login page --->
<div id='slpage' style=" border-radius:5px;  margin:auto; margin-top:50px;    -webkit-box-shadow: -3px 3px 10px #989898; -moz-box-shadow: -3px 3px 10px #989898;
box-shadow: 0px 3px 10px #000; width:70%;   background:#fff;  border-right:solid thick #4099FF;  border-left:solid thick #4099FF;">

<div style="color:#fff; height:5%; background:#4099FF; width:94%; font-family:'Gill Sans', 'Gill Sans MT', 'Myriad Pro', 'DejaVu Sans Condensed', Helvetica, Arial, sans-serif; font-size:24px; padding:3%;">Keengaze
</div>
<div id="sup" style="color:#fff; background:#FFF; width:94%; font-family:'Gill Sans', 'Gill Sans MT', 'Myriad Pro', 'DejaVu Sans Condensed', Helvetica, Arial, sans-serif; font-size:24px; padding:3%; text-align:center;">
<div style=" width:50%; display:inline-block; color:#4099FF; ">
Trust Us ! its free forever.
<input id='uname' type="text" name="uname" style="width:96%; font-size:17px; padding:1%; border-top:0; border-left:0; border-right:0; border-bottom:solid thin #4099FF; outline:0;" placeholder="Username" />
<input id='email' type="text" name="email" style="width:96%; font-size:17px; padding:1%; border-top:0; border-left:0; border-right:0; border-bottom:solid thin #4099FF; outline:0;" placeholder="Email" />
<input id='pass' type="password" name="password" style="width:96%; font-size:17px; padding:1%; border-top:0; border-left:0; border-right:0; border-bottom:solid thin #4099FF; outline:0;" placeholder="Password"  />
<input id='rthis' type="submit" value="Sign up"  style="width:100%; font-size:17px; margin-top:5%; border-radius:2px; padding:1%; border-top:0; border-left:0; border-right:0; border-bottom:solid thin #4099FF; outline:0; background:#4099FF; color:#fff; cursor:pointer;" />


</div>

</div>



<div id="loggg" style="color:#fff;  display:none; background:#FFF; width:94%; font-family:'Gill Sans', 'Gill Sans MT', 'Myriad Pro', 'DejaVu Sans Condensed', Helvetica, Arial, sans-serif; font-size:24px; padding:3%; text-align:center;">
<div style=" width:50%; display:inline-block; color:#4099FF; ">
Trust Us ! its free forever.
<input type="text" id='ema' name="email" style="width:96%; font-size:17px; padding:1%; border-top:0; border-left:0; border-right:0; border-bottom:solid thin #4099FF; outline:0;" placeholder="Email" />
<input type="password" id='pas' name="password" style="width:96%; font-size:17px; padding:1%; border-top:0; border-left:0; border-right:0; border-bottom:solid thin #4099FF; outline:0;" placeholder="Password"  />
<input id='thisis' type="submit" value="Log in"  style="width:100%; font-size:17px; margin-top:5%; border-radius:2px; padding:1%; border-top:0; border-left:0; border-right:0; border-bottom:solid thin #4099FF; outline:0; background:#4099FF; color:#fff; cursor:pointer;" />
<div id='p1' style="position:fixed; cursor:pointer; display:none; top:0; left:0; width:100%; height:100%; background:rgba(3,3,3,0.8);"></div>

<div id='p2' style="position:fixed; top:100px; display:none; left:0; right:0;  margin-left:auto; padding-top:50px;  margin-right:auto; width:50%;  background:#fff;">Please provide your email<br/><br/>
<form method="post" action="./changer.php">

<input type="text" id='emx' name="emailx" style="margin-bottom:50px; width:60%; border-left:0; border-top:0; border-right:0; padding:10px; border-bottom:solid thin #575757; outline:0;" placeholder="Type your email"/>

<input type="submit" name="sub" id='sme' style="margin-bottom:50px; width:60%; border-left:0; border-top:0; border-right:0; padding:10px; border-bottom:solid thin #575757; outline:0;"/>
</form>
</div>
<div id='fp' style=" font-size:16px; cursor:pointer; padding-top:10px; cursor:pointer;">

Forgot password ?
</div>
<script>
$(document).ready(function(e) {
	
	$('#fp').click(function(){
		$('#p1').fadeIn();
		$('#p2').fadeIn();
		});
		$('#p1').click(function(){
		$('#p1').fadeOut();
		$('#p2').fadeOut();
		});
	
    $('#thisis').click(function(){
		var unameu=$('#ema').val();
		var passu=$('#pas').val();
		
		$.ajax({
			url:'./testme.php',
			type:'POST',
			data:{unameu:unameu,passu:passu},
			success: function(data){
				if(data=="1"){
					
						window.location.href='./trash.php';
					
					}else{
						
					alert('Incorrect Username and Password Combination!');
					
					};
				}
			
			});
		
		
		
		});
});
</script>
</div>

</div>

<div id="login" style="color:#fff;    background:#4099FF; width:94%; font-family:'Gill Sans', 'Gill Sans MT', 'Myriad Pro', 'DejaVu Sans Condensed', Helvetica, Arial, sans-serif; font-size:24px; padding:3%; text-align:center; cursor:pointer;">Or, Simply Log in.</div>
<div id="loginn" style="color:#fff; height:5%; display:none;  background:#4099FF; width:94%; font-family:'Gill Sans', 'Gill Sans MT', 'Myriad Pro', 'DejaVu Sans Condensed', Helvetica, Arial, sans-serif; font-size:24px; padding:3%; text-align:center; cursor:pointer;">Sign Up ! If You're a New User.</div>

</div>

<div style="width:100%; text-align:center; font-family:'Gill Sans', 'Gill Sans MT', 'Myriad Pro', 'DejaVu Sans Condensed', Helvetica, Arial, sans-serif; font-size:24px;">
<div id='error123' style="color:red; padding:10px;  display:none;">All fields are missing.</div>
<div id='error23' style="color:red; padding:10px;  display:none;">Email and password is missing.</div>
<div id='error12' style="color:red; padding:10px;  display:none;">Email and user is missing.</div>
<div id='error13' style="color:red; padding:10px; display:none;">Username and password is missing.</div>

<div id='error3' style="color:red; padding:10px;  display:none;">password is missing</div>
<div id='error2' style="color:red; padding:10px;  display:none;">Email is missing</div>
<div id='error1' style="color:red; padding:10px;  display:none;">Username is missing</div>


<div id='errorx' style="color:red; padding:10px;  display:none;">Email is not Valid !</div>
<div id='errory' style="color:red; padding:10px;  display:none; color:rgba(0,128,64,1);">Email is Valid !</div>
</div>


<!--- Close ---->

<!-- Front page  -->

<div id='text2' style="position:fixed; top:90%; z-index:500; color:#fff; font-family:'Gill Sans', 'Gill Sans MT', 'Myriad Pro', 'DejaVu Sans Condensed', Helvetica, Arial, sans-serif; font-size:16px; left:0; right:0; margin-left:auto; margin-right:auto; width:50%; text-align:center; height:100px;">Copyright 2015 | All Rights Reserved | <a style="color:#fff; text-decoration:none;" href="./aboutn.php">About</a></div>

<div id='text3' style="position:fixed; top:95%; z-index:500; color:#fff; font-family:'Gill Sans', 'Gill Sans MT', 'Myriad Pro', 'DejaVu Sans Condensed', Helvetica, Arial, sans-serif; font-size:16px; left:0; right:0; margin-left:auto; margin-right:auto; width:50%; text-align:center; height:100px;">Powered by RAJ KM</div>

<!--Close-->

</body>
</html>