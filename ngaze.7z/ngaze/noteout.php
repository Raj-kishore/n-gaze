


<?php
require"./connect.php";
$query=mysql_query("SELECT * FROM ndata ORDER BY id DESC");
while($fquery=mysql_fetch_assoc($query)){
$thisid=$fquery['id'];
$text=$fquery['tex'];
$date=$fquery['dat'];
$time=$fquery['tim'];



echo"
<body>
<div onClick='funct(this,$thisid)' id='n$thisid' class='notes' style='width:100%; border-bottom:solid thin #999; cursor:pointer;'>
<div style=' width:100%; padding:2%; font-size:25px; '>$text</div>
<div style=' width:100%;'>
<div style='float:left; color:#4099FF; width:60%;'>$time</div>
<div style='float:left; width:30%; color:#4099FF;  float:right;' >$date</div>
<div style='clear:both;'></div>
</div>
</div>
<script>

function funct(t,y){
	 $.ajax({
        url:'noteoutone.php',
	    type: 'POST',
        data: {id:y},
        success: function (data) {
        $('#sme').html(data);
        },
        cache: false,
		});
		          }

</script>
</body>
";

}
?>
