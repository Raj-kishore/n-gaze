<?php
error_reporting(E_ALL^E_NOTICE);
session_start();
$userid = $_SESSION['userid'];
$username = $_SESSION['username'];
	
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>loggedout</title>
</head>

<body>
<?php
session_destroy();
	header("location: http://localhost/index.php");
?>

</body>
</html>