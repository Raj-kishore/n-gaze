<?php
error_reporting(E_ALL^E_NOTICE);
session_start();
$userid = $_SESSION['userid'];
$uu=$_GET['id'];
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Tash here!</title>
<script src="jquery.min.js">
</script>
<style>
.notes{
	font-family:"Gill Sans", "Gill Sans MT", "Myriad Pro", "DejaVu Sans Condensed", Helvetica, Arial, sans-serif;
	color:#333;	
}
body{
	background:url(all/explore-clouds-powerpoint-backgrounds.jpg);
	background-size:cover;
	background-attachment:fixed;
	-webkit-transition: all 0.2s ease;
	-moz-transition: all 0.2s ease;
	-ms-transition: all 0.2s ease;
	-o-transition: all 0.2s ease;
	transition: all 0.2s ease;
}
#feedy{
	display:inline-block;
	 width:65%; 
	 vertical-align:top; 
	 color:#696969;
	  background:#fff;
	}
	#td{
		width:100%; height:20%; font-size:16px; text-align:right;
	}
	#feedx{
		display:inline-block; width:25%;  color:#ccc; vertical-align:top; background:#fff;
	}


#l3{display:inline-block; width:20%; height:100%; background:#4099FF; position:relative;}
#l2{display:inline-block; width:55%; height:100%; background:#4099FF; text-align:left; color:#999; position:relative;}
#l1{display:inline-block; width:20%; height:100%; color:#424242; position:relative;}

@media screen and (max-width: 730px) {

#feedy{
	width:100%;  
}
#feedx{
	width:100%;  
}
#td{
	margin-top:10px;
	font-size:12px;
}
	#l3{width:100%;}
	#l2{display:none;}
	
	#l1{width:100%; text-align:center;}
}

</style>
</head>

<body>

<div style="position:fixed; width:100%; background:rgb(64, 153, 255); top:0; left:0; font-family:'Gill Sans', 'Gill Sans MT', 'Myriad Pro', 'DejaVu Sans Condensed', Helvetica, Arial, sans-serif; font-size:30px; height:50px; color:white; ">
<div style="text-align:center; width:100%; height:100%;">

<div id='l1'>
<div style=" position:absolute; margin-top:7px;  color:#fff; left:0; right:0; margin-left:auto; margin-right:auto;"><a style=" color:#fff; text-decoration:none; cursor:pointer;" href='./trash.php'>
Keengaze

</a></div>
</div>

<div id='l2' >
</div>
<div id='l3'>

<div style=" position:absolute; margin-top:2px;  color:#999; padding-left:10px; left:0; right:0; margin-left:auto; margin-right:auto;">

<?php
if(!isset($userid)){
echo "

<a style='color:#fff; text-decoration:none; font-size:16px;' href='./index.php'>
Log In
</a>
";
}else{
	echo"
	
<a style='color:#fff; text-decoration:none; margin-right:30px; font-size:16px;' href='./pnote.php'>Private notes</a>
<a style='color:#fff; text-decoration:none; margin-right:30px; font-size:16px;' href='./setme.php'>Setting</a>
	<a style='color:#fff; text-decoration:none; font-size:16px;' href='./loggedout.php'>
Log out
</a>
	";

	}
?>


</div>
</div>
</div>
</div>







<div style="width:1000px; margin:10px auto; position:relative; margin-bottom:10px; background:rgba(255,255,255,0.7); color:#fff; font-family:'Gill Sans', 'Gill Sans MT', 'Myriad Pro', 'DejaVu Sans Condensed', Helvetica, Arial, sans-serif; font-size:24px; border-radius:10px; ">



</div>

<div style="width:90%; margin:10px auto; margin-top:150px; font-family:'Gill Sans', 'Gill Sans MT', 'Myriad Pro', 'DejaVu Sans Condensed', Helvetica, Arial, sans-serif; background:rgba(255,255,255,0.8); border-radius:10px;">

<div style=" color:#4099FF; float:left; margin:10px; font-size:20px; text-decoration:underline; cursor:pointer;">Feeds</div>


<?php
if(isset($userid)){

echo"

<div style=' color:#4099FF; float:left; margin:10px; font-size:20px; cursor:pointer;'><a style='text-decoration:none; color:#4099FF; ' 
href='./npadpro.php?id=$userid'>Profile</a></div>
<div style=' color:#4099FF; float:left; margin:10px; font-size:20px; cursor:pointer;'><a style='text-decoration:none; color:#4099FF; ' href='./gaze.php'>Gazes</a></div>
";
}
?>
<div style="clear:both;"></div>

<?php
if(isset($userid)){
echo "

<textarea id='ndata' name='textarea' style=\"background:#fff; width:98%; border:0; outline:0; height:100px; font-family:'Gill Sans', 'Gill Sans MT', 'Myriad Pro', 'DejaVu Sans Condensed', Helvetica, Arial, sans-serif; font-size:18px; padding:1%;\" placeholder='What you think...'>
</textarea>
<input type='text' id='uid' style='display:none;' value='$userid'/>
<div id='into' style='background:#fff; width:98%; cursor:pointer; padding:1%; background:#4099FF; color:#fff; font-size:20px; text-align:center;'>Post</div>



";
}

?>



<script>
$(document).ready(function(e) {
	
	var uid = $('#uid').val();

    $("#into").click(function(e){
		
		var ndata = $('#ndata').val();	
		
		if(ndata==""){
	
		}else{
					
		$.ajax({
			url:"./intonpadx.php",
			type:"POST",
			data:{ndata:ndata,uid:uid},
			beforeSend: function(){
				$('#feedy').html("<div style='margin-top:30px; margin-bottom:30px;'>Loading...<div>");
				},
			success: function(data){
				$('#feedy').html(data);
				$('#ndata').val("");
				
				}
		  
			});
			
			
			};
		});
});
</script>



<div style=" width:100%; cursor:pointer; margin-bottom:100px; color:#fff; font-size:20px; text-align:center;">

<div id='feedy'>
<?php
require"./connect.php";
$find=mysql_query("SELECT * FROM tyo ORDER BY id DESC");
while($ffind=mysql_fetch_assoc($find)){
$txtid=$ffind['id'];
$txts=$ffind['ndata'];
$timex=$ffind['ntime'];
$datex=$ffind['ndate'];
$user=$ffind['uid'];

$uquery=mysql_query("SELECT * FROM newusers WHERE id='$user'");
$finder=mysql_fetch_assoc($uquery);
$nameget=$finder['uname'];
$idget=$finder['id'];



$se=mysql_query("SELECT * FROM gazes WHERE tno='$txtid'");
$nse=mysql_num_rows($se);



$co=mysql_query("SELECT * FROM gazes WHERE tno='$txtid' AND uid='$userid'");
$coo=mysql_num_rows($co);


if($coo=="0"){

echo"

<div style='width:92%; background:rgba(108,108,108,0.1);  margin:2%; padding:2%;'>
<div style='text-align:left; padding-bottom:10px; font-size:16px; '>
<a style='text-decoration:none; color:#4099FF; ' href='./npadpro.php?id=$user'>$nameget</a>
</div>
<div  style='width:100%; text-align:left;'>
<div id='ju$txtid'>
$txts
</div>
";

if(isset($userid)){
echo "


<div style='position:relative; width:100%;'>
<div id='b$txtid' style='width:100%; position:absolute; top:0; left:0; color:#4099FF;'> Gaze </div>
<div id='c$txtid' style='width:100%; position:absolute; top:0; left:0; display:none; color:#4099FF;'> Ungaze </div>
</div>
";

}
echo"
<div id='nhere$txtid' style='width:100%; margin-top:25px; font-size:16px; color:#999; '>$nse gaze</div>
<script>
$(document).ready(function(){
	
	$('#ju$txtid').hover(function(){
		$(this).css({'color':'#000'});
	},function(){
			$(this).css({'color':'#696969'});
		
		});
	
		$('#ju$txtid').click(function(){
			
			var hii=$txtid;
	
		window.location.href='./where.php?tid='+hii;
	
	});
	
	
	$('#b$txtid').click(function(){
		var uidc=$userid;
		var thrc=$txtid;
	
	$.ajax({
		url:'./gazeme.php',
		type:'POST',
		data:{uidc:uidc,thrc:thrc},
		success:function(data){
			
			$('#c$txtid').fadeIn(200);
			$('#b$txtid').fadeOut(200);
			$('#nhere$txtid').html(data);
		
			}
		});
		
		
			});
			
				
	$('#c$txtid').click(function(){
			var uidc=$userid;
		var thrc=$txtid;
	
	$.ajax({
		url:'./ungazeme.php',
		type:'POST',
		data:{uidc:uidc,thrc:thrc},
		success:function(data){
			$('#b$txtid').fadeIn(200);
			$('#c$txtid').fadeOut(200);
			$('#nhere$txtid').html(data);
			}
		});
		
		
			});
	
	});
</script>
</div>
<div id='td'>
$timex | $datex
</div>
</div>


";
}else{
	echo"

<div style='width:92%;  background:rgba(108,108,108,0.1);  margin:2%; padding:2%;'>
<div style='text-align:left; padding-bottom:10px; font-size:16px; '>
<a style='text-decoration:none; color:#4099FF; ' href='./npadpro.php?id=$user'>$nameget</a>
</div>
<div  style='width:100%; text-align:left;'>
<div id='ju$txtid'>
$txts
</div>
";

if(isset($userid)){
echo "

<div style='position:relative; width:100%;'>
<div id='b$txtid' style='width:100%; position:absolute; top:0; left:0; display:none; color:#4099FF;'> Gaze </div>
<div id='c$txtid' style='width:100%; position:absolute; top:0; left:0;  color:#4099FF;'> Ungaze </div>
</div>
";
}

echo"

<div id='nhere$txtid' style='width:100%; margin-top:25px; font-size:16px; color:#999; '>$nse gaze</div>
<script>
$(document).ready(function(){
	
	$('#ju$txtid').hover(function(){
		$(this).css({'color':'#000'});
	},function(){
			$(this).css({'color':'#696969'});
				
		});
	
		$('#ju$txtid').click(function(){
			
			var hii=$txtid;
	
		window.location.href='./where.php?tid='+hii;
	
	});
	
	
	$('#b$txtid').click(function(){
		var uidc=$userid;
		var thrc=$txtid;
	
	$.ajax({
		url:'./gazeme.php',
		type:'POST',
		data:{uidc:uidc,thrc:thrc},
		success:function(data){
			
			$('#c$txtid').fadeIn(200);
			$('#b$txtid').fadeOut(200);
			$('#nhere$txtid').html(data);
		
			}
		});
		
		
			});
			
				
	$('#c$txtid').click(function(){
			var uidc=$userid;
		var thrc=$txtid;
	
	$.ajax({
		url:'./ungazeme.php',
		type:'POST',
		data:{uidc:uidc,thrc:thrc},
		success:function(data){
			$('#b$txtid').fadeIn(200);
			$('#c$txtid').fadeOut(200);
			$('#nhere$txtid').html(data);
			}
		});
		
		
			});
	
	});
</script>
</div>
<div id='td'>
$timex | $datex
</div>
</div>


";
	
	}

}
?>


</div>
<div id='feedx'>
Potential users
<br/>

<?php
require"./connect.php";
$q=mysql_query("SELECT * FROM newusers ORDER BY id DESC");
while($fq=mysql_fetch_assoc($q)){
	$mname=$fq['uname'];
	$mid=$fq['id'];
	
$nnn=mysql_query("SELECT * FROM nfiles WHERE uid='$mid' ORDER BY id DESC");
$nnnn=mysql_fetch_assoc($nnn);
$immg=$nnnn['hspot'];
	
	if($immg){
		echo "
	
<div style='width:100%; '>
<img style='float:left; margin:10px; border-radius:20px;' width='40px' height='40px' src='img/$immg'/>
<div style='float:left; margin:20px; font-size:16px; '><a style='color:#4099FF; text-decoration:none;' href='./npadpro.php?id=$mid'>$mname</a></div>
<div style='clear:both;'></div>
</div> 



	";
		}else{
		echo "
	
<div style='width:100%; '>
<img style='float:left; margin:10px; border-radius:20px;' width='40px' height='40px' src='all/ano.jpg'/>
<div style='float:left; margin:20px; font-size:16px; '><a style='color:#4099FF; text-decoration:none;' href='./npadpro.php?id=$mid'>$mname</a></div>
<div style='clear:both;'></div>
</div> 



	";
		
		
		}
	
	
	
	}


?>


</div>

</div>

</div>

</div>


<div id='text2' style=" color:#fff; font-family:'Gill Sans', 'Gill Sans MT', 'Myriad Pro', 'DejaVu Sans Condensed', Helvetica, Arial, sans-serif; font-size:16px; width:50%; margin:auto; text-align:center; height:100px;">Copyright 2015 | All Rights Reserved | <a style="color:fff; text-decoration:none;" href="./aboutn.php">About</a></div>

<div id='text3' style="color:#fff; font-family:'Gill Sans', 'Gill Sans MT', 'Myriad Pro', 'DejaVu Sans Condensed', Helvetica, Arial, sans-serif; font-size:16px;  width:50%; margin:auto; text-align:center; height:100px;">Powered by RAJ KM</div>

</body>
</html>