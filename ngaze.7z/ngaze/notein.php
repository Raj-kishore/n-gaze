<?php

session_start();
$userid = $_SESSION['userid'];

require"./connect.php";
error_reporting(E_ALL^E_NOTICE);

$userid=$_POST['userid'];

$text=$_POST['text'];
$date= date("F d, Y");
date_default_timezone_set("Asia/Calcutta");
$time= date("h:i:sa");

mysql_query("INSERT INTO ndata VALUES('','$text','$date','$time','$userid')");
echo"done";

?>